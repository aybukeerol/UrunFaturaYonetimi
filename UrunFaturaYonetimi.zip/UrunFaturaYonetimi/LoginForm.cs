﻿using System;
using System.Drawing;
using System.Windows.Forms;
using UrunFaturaYonetimi.Business.Abstract;
using UrunFaturaYonetimi.Business.Managers;

namespace UrunFaturaYonetimi
{
    public partial class LoginForm : Form
    {
        private readonly IUserService _userService;

        private TextBox txtKullanici;
        private TextBox txtSifre;

        private CheckBox chkSifreGoster;

        private Button btnGiris;

        private LinkLabel lnkKayitOl;
        private LinkLabel lnkSifremiUnuttum;

        public LoginForm()
            : this(new UserManager())
        {
        }

        public LoginForm(IUserService userService)
        {
            _userService = userService;

            FormuOlustur();
        }

        private void FormuOlustur()
        {
            Text =
                "E-Fatura Yönetimi - Giriş";

            StartPosition =
                FormStartPosition.CenterScreen;

            Size =
                new Size(
                    1100,
                    680);

            MinimumSize =
                new Size(
                    950,
                    600);

            BackColor =
                Color.FromArgb(
                    244,
                    247,
                    251);

            Font =
                new Font(
                    "Segoe UI",
                    10F);

            // =====================================================
            // SOL PANEL
            // =====================================================

            Panel pnlSol =
                new Panel();

            pnlSol.Dock =
                DockStyle.Left;

            pnlSol.Width =
                450;

            pnlSol.BackColor =
                Color.FromArgb(
                    18,
                    38,
                    66);

            Label logo =
                new Label();

            logo.Text =
                "e-Portal";

            logo.AutoSize =
                true;

            logo.Font =
                new Font(
                    "Segoe UI",
                    25F,
                    FontStyle.Bold);

            logo.ForeColor =
                Color.White;

            logo.Location =
                new Point(
                    55,
                    80);

            pnlSol.Controls.Add(
                logo);

            Label title =
                new Label();

            title.Text =
                "Fatura ve Cari\nYönetim Sistemi";

            title.AutoSize =
                true;

            title.Font =
                new Font(
                    "Segoe UI",
                    21F,
                    FontStyle.Bold);

            title.ForeColor =
                Color.White;

            title.Location =
                new Point(
                    55,
                    170);

            pnlSol.Controls.Add(
                title);

            Label description =
                new Label();

            description.Text =
                "Müşteri, firma, cari hesap,\n" +
                "ürün ve fatura işlemlerinizi\n" +
                "tek noktadan yönetin.";

            description.AutoSize =
                true;

            description.Font =
                new Font(
                    "Segoe UI",
                    11F);

            description.ForeColor =
                Color.FromArgb(
                    187,
                    201,
                    220);

            description.Location =
                new Point(
                    60,
                    280);

            pnlSol.Controls.Add(
                description);

            // =====================================================
            // SAĞ PANEL
            // =====================================================

            Panel pnlSag =
                new Panel();

            pnlSag.Dock =
                DockStyle.Fill;

            pnlSag.BackColor =
                Color.White;

            Panel card =
                new Panel();

            card.Size =
                new Size(
                    410,
                    500);

            card.BackColor =
                Color.White;

            pnlSag.Controls.Add(
                card);

            pnlSag.Resize +=
                delegate
                {
                    card.Left =
                        (pnlSag.ClientSize.Width -
                         card.Width) / 2;

                    card.Top =
                        (pnlSag.ClientSize.Height -
                         card.Height) / 2;
                };

            // =====================================================
            // BAŞLIK
            // =====================================================

            Label lblGiris =
                new Label();

            lblGiris.Text =
                "Hoş Geldiniz";

            lblGiris.AutoSize =
                true;

            lblGiris.Font =
                new Font(
                    "Segoe UI",
                    24F,
                    FontStyle.Bold);

            lblGiris.ForeColor =
                Color.FromArgb(
                    32,
                    45,
                    62);

            lblGiris.Location =
                new Point(
                    15,
                    10);

            card.Controls.Add(
                lblGiris);

            Label lblAciklama =
                new Label();

            lblAciklama.Text =
                "Hesabınıza giriş yapın.";

            lblAciklama.AutoSize =
                true;

            lblAciklama.ForeColor =
                Color.Gray;

            lblAciklama.Location =
                new Point(
                    19,
                    68);

            card.Controls.Add(
                lblAciklama);

            // =====================================================
            // KULLANICI
            // =====================================================

            card.Controls.Add(
                FormLabel(
                    "Kullanıcı Adı / E-posta",
                    18,
                    125));

            txtKullanici =
                new TextBox();

            txtKullanici.Location =
                new Point(
                    18,
                    153);

            txtKullanici.Size =
                new Size(
                    365,
                    32);

            txtKullanici.Font =
                new Font(
                    "Segoe UI",
                    11F);

            card.Controls.Add(
                txtKullanici);

            // =====================================================
            // ŞİFRE
            // =====================================================

            card.Controls.Add(
                FormLabel(
                    "Şifre",
                    18,
                    215));

            txtSifre =
                new TextBox();

            txtSifre.Location =
                new Point(
                    18,
                    243);

            txtSifre.Size =
                new Size(
                    365,
                    32);

            txtSifre.Font =
                new Font(
                    "Segoe UI",
                    11F);

            txtSifre.UseSystemPasswordChar =
                true;

            card.Controls.Add(
                txtSifre);

            // =====================================================
            // ŞİFRE GÖSTER
            // =====================================================

            chkSifreGoster =
                new CheckBox();

            chkSifreGoster.Text =
                "Şifreyi göster";

            chkSifreGoster.AutoSize =
                true;

            chkSifreGoster.ForeColor =
                Color.Gray;

            chkSifreGoster.Location =
                new Point(
                    18,
                    290);

            chkSifreGoster.CheckedChanged +=
                delegate
                {
                    txtSifre.UseSystemPasswordChar =
                        !chkSifreGoster.Checked;
                };

            card.Controls.Add(
                chkSifreGoster);

            // =====================================================
            // ŞİFREMİ UNUTTUM
            // =====================================================

            lnkSifremiUnuttum =
                new LinkLabel();

            lnkSifremiUnuttum.Text =
                "Şifremi Unuttum";

            lnkSifremiUnuttum.AutoSize =
                true;

            lnkSifremiUnuttum.Location =
                new Point(
                    267,
                    292);

            lnkSifremiUnuttum.LinkColor =
                Color.FromArgb(
                    35,
                    102,
                    215);

            lnkSifremiUnuttum.Cursor =
                Cursors.Hand;

            lnkSifremiUnuttum.Click +=
                SifremiUnuttum_Click;

            card.Controls.Add(
                lnkSifremiUnuttum);

            // =====================================================
            // GİRİŞ YAP
            // =====================================================

            btnGiris =
                new Button();

            btnGiris.Text =
                "GİRİŞ YAP";

            btnGiris.Location =
                new Point(
                    18,
                    335);

            btnGiris.Size =
                new Size(
                    365,
                    48);

            btnGiris.FlatStyle =
                FlatStyle.Flat;

            btnGiris.FlatAppearance.BorderSize =
                0;

            btnGiris.BackColor =
                Color.FromArgb(
                    35,
                    102,
                    215);

            btnGiris.ForeColor =
                Color.White;

            btnGiris.Font =
                new Font(
                    "Segoe UI",
                    10F,
                    FontStyle.Bold);

            btnGiris.Cursor =
                Cursors.Hand;

            btnGiris.Click +=
                BtnGiris_Click;

            card.Controls.Add(
                btnGiris);

            // =====================================================
            // KAYIT OL
            // =====================================================

            Label lblHesap =
                new Label();

            lblHesap.Text =
                "Hesabınız yok mu?";

            lblHesap.AutoSize =
                true;

            lblHesap.ForeColor =
                Color.Gray;

            lblHesap.Location =
                new Point(
                    90,
                    420);

            card.Controls.Add(
                lblHesap);

            lnkKayitOl =
                new LinkLabel();

            lnkKayitOl.Text =
                "Kayıt Ol";

            lnkKayitOl.AutoSize =
                true;

            lnkKayitOl.Font =
                new Font(
                    "Segoe UI",
                    9.5F,
                    FontStyle.Bold);

            lnkKayitOl.LinkColor =
                Color.FromArgb(
                    35,
                    102,
                    215);

            lnkKayitOl.Location =
                new Point(
                    220,
                    420);

            lnkKayitOl.Cursor =
                Cursors.Hand;

            lnkKayitOl.Click +=
                KayitOl_Click;

            card.Controls.Add(
                lnkKayitOl);

            Controls.Add(
                pnlSag);

            Controls.Add(
                pnlSol);

            AcceptButton =
                btnGiris;
        }

        // =========================================================
        // NORMAL GİRİŞ
        // =========================================================

        private void BtnGiris_Click(
            object sender,
            EventArgs e)
        {
            string login =
                txtKullanici.Text.Trim();

            string password =
                txtSifre.Text;

            if (login == "")
            {
                Uyari(
                    "Kullanıcı adı veya e-posta adresinizi giriniz.");

                txtKullanici.Focus();

                return;
            }

            if (password == "")
            {
                Uyari(
                    "Şifrenizi giriniz.");

                txtSifre.Focus();

                return;
            }

            UserAccount user =
                _userService.Login(
                    login,
                    password);

            if (user == null)
            {
                Uyari(
                    "Kullanıcı adı / e-posta veya şifre hatalı.");

                txtSifre.SelectAll();

                txtSifre.Focus();

                return;
            }

            AnaEkraniAc(user);
        }

        // =========================================================
        // KAYIT OL
        // =========================================================

        private void KayitOl_Click(
            object sender,
            EventArgs e)
        {
            using (RegisterForm form =
                new RegisterForm(
                    _userService))
            {
                DialogResult result =
                    form.ShowDialog(
                        this);

                if (result ==
                    DialogResult.OK)
                {
                    txtSifre.Clear();

                    txtKullanici.Focus();
                }
            }
        }

        // =========================================================
        // ŞİFREMİ UNUTTUM
        // =========================================================

        private void SifremiUnuttum_Click(
            object sender,
            EventArgs e)
        {
            using (ForgotPasswordForm form =
                new ForgotPasswordForm(_userService))
            {
                DialogResult result =
                    form.ShowDialog(
                        this);

                if (result ==
                        DialogResult.OK &&
                    form.VerifiedUser != null)
                {
                    AnaEkraniAc(
                        form.VerifiedUser);
                }
            }
        }

        // =========================================================
        // ANA EKRAN
        // =========================================================

        private void AnaEkraniAc(
            UserAccount user)
        {
            Hide();

            MainForm mainForm =
                new MainForm(
                    user.Username,
                    _userService);

            mainForm.Shown +=
                delegate
                {
                    if (!user.MustChangePassword)
                    {
                        return;
                    }

                    using (ChangePasswordForm changeForm =
                        new ChangePasswordForm(
                            user,
    _userService))
                    {
                        DialogResult result =
                            changeForm.ShowDialog(
                                mainForm);

                        if (result != DialogResult.OK ||
                            !changeForm.PasswordChanged)
                        {
                            mainForm.Close();
                        }
                    }
                };

            mainForm.FormClosed +=
                delegate
                {
                    if (!IsDisposed)
                    {
                        txtSifre.Clear();

                        Show();
                    }
                };

            mainForm.Show();
        }

        // =========================================================
        // FORM LABEL
        // =========================================================

        private Label FormLabel(
            string text,
            int x,
            int y)
        {
            Label label =
                new Label();

            label.Text =
                text;

            label.AutoSize =
                true;

            label.Font =
                new Font(
                    "Segoe UI",
                    9F,
                    FontStyle.Bold);

            label.ForeColor =
                Color.FromArgb(
                    70,
                    82,
                    98);

            label.Location =
                new Point(
                    x,
                    y);

            return label;
        }

        // =========================================================
        // UYARI
        // =========================================================

        private void Uyari(
            string message)
        {
            MessageBox.Show(
                message,
                "Uyarı",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
        }
    }
}
