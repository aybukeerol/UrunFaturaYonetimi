﻿using System;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;

namespace UrunFaturaYonetimi
{
    public class YeniFaturaForm : Form
    {
        // ============================================================
        // RENKLER
        // ============================================================

        private readonly Color PrimaryBlue = Color.FromArgb(10, 91, 190);
        private readonly Color PrimaryBlueDark = Color.FromArgb(7, 72, 155);

        private readonly Color Background = Color.FromArgb(231, 237, 244);
        private readonly Color LeftBackground = Color.FromArgb(248, 250, 252);
        private readonly Color RightBackground = Color.FromArgb(229, 235, 242);

        private readonly Color BorderColor = Color.FromArgb(207, 216, 226);

        private readonly Color TextPrimary = Color.FromArgb(30, 38, 49);
        private readonly Color TextSecondary = Color.FromArgb(91, 103, 118);

        private readonly Color Success = Color.FromArgb(5, 155, 100);
        private readonly Color SuccessBackground = Color.FromArgb(226, 249, 238);

        // ============================================================
        // AKTİF KULLANICI
        // ============================================================

        private string aktifKullaniciAdi = "";
        private string aktifKullaniciRol = "";

        // ============================================================
        // KONTROLLER
        // ============================================================

        private Panel topBar;
        private Panel pageHeader;

        private Panel solContainer;
        private Panel sagContainer;

        private ComboBox cmbSenaryo;
        private ComboBox cmbFaturaTipi;
        private ComboBox cmbParaBirimi;

        private TextBox txtFaturaNo;
        private TextBox txtSiparisNo;

        private DateTimePicker dtpTarih;
        private DateTimePicker dtpSaat;

        private TextBox txtAlici;
        private TextBox txtKimlikNo;
        private TextBox txtVergiDairesi;
        private TextBox txtAdres;
        private TextBox txtEmail;
        private TextBox txtTelefon;

        private DataGridView dgvKalemler;
        private DataGridView dgvOnizleme;

        private Label prvFaturaNo;
        private Label prvTarih;
        private Label prvSaat;
        private Label prvSenaryo;
        private Label prvTip;

        private Label prvAlici;
        private Label prvAdres;
        private Label prvVergi;
        private Label prvKimlik;
        private Label prvEmail;
        private Label prvTelefon;

        private Label prvAraToplam;
        private Label prvIskonto;
        private Label prvKdv;
        private Label prvGenelToplam;

        private bool hesaplamaYapiliyor = false;

        // ============================================================
        // CONSTRUCTOR
        //
        // MainForm'daki:
        // new YeniFaturaForm()
        //
        // DEĞİŞMEZ.
        // ============================================================

        public YeniFaturaForm()
        {
            AktifKullaniciyiBul();
            FormuOlustur();
        }

        // ============================================================
        // AKTİF KULLANICIYI AÇIK ANA FORMDAN BUL
        // ============================================================

        private void AktifKullaniciyiBul()
        {
            aktifKullaniciAdi = "";
            aktifKullaniciRol = "";

            foreach (Form form in Application.OpenForms)
            {
                if (form == this)
                    continue;

                KullaniciKontroluAra(form.Controls);

                if (!string.IsNullOrWhiteSpace(aktifKullaniciAdi))
                    break;
            }
        }

        private void KullaniciKontroluAra(
            Control.ControlCollection controls)
        {
            foreach (Control control in controls)
            {
                if (!string.IsNullOrWhiteSpace(aktifKullaniciAdi))
                    return;

                Label lbl = control as Label;

                if (lbl != null)
                {
                    string name =
                        (lbl.Name ?? "")
                        .Replace("_", "")
                        .ToLowerInvariant();

                    string text =
                        (lbl.Text ?? "").Trim();

                    bool kullaniciLabeli =
                        name.Contains("kullaniciadi") ||
                        name.Contains("kullanici") ||
                        name.Contains("username") ||
                        name.Contains("user") ||
                        name.Contains("adsoyad") ||
                        name.Contains("aktifhesap") ||
                        name.Contains("hesapadi") ||
                        name.Contains("profiladi");

                    if (kullaniciLabeli &&
                        KullaniciAdiGecerliMi(text))
                    {
                        aktifKullaniciAdi = text;
                        aktifKullaniciRol = RolBul(lbl.Parent);
                        return;
                    }
                }

                if (control.HasChildren)
                    KullaniciKontroluAra(control.Controls);
            }
        }

        private string RolBul(Control parent)
        {
            if (parent == null)
                return "";

            foreach (Control control in parent.Controls)
            {
                Label lbl = control as Label;

                if (lbl == null)
                    continue;

                string name =
                    (lbl.Name ?? "")
                    .Replace("_", "")
                    .ToLowerInvariant();

                string text =
                    (lbl.Text ?? "").Trim();

                if (name.Contains("rol") ||
                    name.Contains("role") ||
                    name.Contains("yetki") ||
                    name.Contains("unvan"))
                {
                    return text;
                }
            }

            return "";
        }

        private bool KullaniciAdiGecerliMi(string text)
        {
            if (string.IsNullOrWhiteSpace(text))
                return false;

            string value = text.Trim();

            if (value.Length < 2)
                return false;

            string lower = value.ToLowerInvariant();

            if (lower == "kullanıcı" ||
                lower == "kullanici" ||
                lower == "admin" ||
                lower == "hesabım" ||
                lower == "hesabim" ||
                lower == "profil" ||
                lower == "yönetici" ||
                lower == "yonetici")
                return false;

            return true;
        }

        private string KullaniciBasHarfi()
        {
            if (string.IsNullOrWhiteSpace(aktifKullaniciAdi))
                return "●";

            string[] parts =
                aktifKullaniciAdi.Split(
                    new char[] { ' ' },
                    StringSplitOptions.RemoveEmptyEntries);

            if (parts.Length == 0)
                return "●";

            if (parts.Length == 1)
                return parts[0].Substring(0, 1).ToUpper();

            return
                parts[0].Substring(0, 1).ToUpper() +
                parts[parts.Length - 1]
                    .Substring(0, 1)
                    .ToUpper();
        }

        // ============================================================
        // FORM
        // ============================================================

        private void FormuOlustur()
        {
            Text = "NEXORA ERP - Yeni Fatura";

            StartPosition = FormStartPosition.CenterScreen;
            WindowState = FormWindowState.Maximized;

            MinimumSize = new Size(1200, 720);

            BackColor = Background;

            Font = new Font("Segoe UI", 9F);

            AutoScaleMode = AutoScaleMode.Dpi;

            // --------------------------------------------------------
            // ANA İÇERİK
            // --------------------------------------------------------

            TableLayoutPanel content =
                new TableLayoutPanel();

            content.Dock = DockStyle.Fill;
            content.ColumnCount = 2;
            content.RowCount = 1;

            content.Margin = Padding.Empty;
            content.Padding = new Padding(10);

            content.BackColor = Background;

            content.ColumnStyles.Add(
                new ColumnStyle(
                    SizeType.Percent,
                    50F));

            content.ColumnStyles.Add(
                new ColumnStyle(
                    SizeType.Percent,
                    50F));

            content.RowStyles.Add(
                new RowStyle(
                    SizeType.Percent,
                    100F));

            solContainer = SolTarafOlustur();
            sagContainer = SagTarafOlustur();

            content.Controls.Add(
                solContainer,
                0,
                0);

            content.Controls.Add(
                sagContainer,
                1,
                0);

            Controls.Add(content);

            // --------------------------------------------------------
            // PAGE HEADER
            // --------------------------------------------------------

            pageHeader = PageHeaderOlustur();

            Controls.Add(pageHeader);

            // --------------------------------------------------------
            // TOP BAR
            // --------------------------------------------------------

            topBar = TopBarOlustur();

            Controls.Add(topBar);

            topBar.BringToFront();
            pageHeader.BringToFront();

            Shown += delegate
            {
                OrnekKalemleriYukle();

                OnizlemeyiGuncelle();

                BeginInvoke(
                    new Action(
                        delegate
                        {
                            solContainer.AutoScrollPosition =
                                new Point(0, 0);

                            sagContainer.AutoScrollPosition =
                                new Point(0, 0);

                            ActiveControl = null;
                        }));
            };
        }

        // ============================================================
        // ÜST BAR
        // ============================================================

        private Panel TopBarOlustur()
        {
            Panel panel = new Panel();

            panel.Dock = DockStyle.Top;
            panel.Height = 65;
            panel.BackColor = Color.White;

            // --------------------------------------------------------
            // LOGO
            // --------------------------------------------------------

            Label logo = new Label();

            logo.Text = "NEXORA";
            logo.AutoSize = true;

            logo.Font =
                new Font(
                    "Georgia",
                    15F,
                    FontStyle.Bold);

            logo.ForeColor = TextPrimary;

            logo.Location =
                new Point(22, 19);

            panel.Controls.Add(logo);

            Label erp = new Label();

            erp.Text = "ERP";
            erp.AutoSize = true;

            erp.Font =
                new Font(
                    "Segoe UI",
                    7F,
                    FontStyle.Bold);

            erp.ForeColor = Color.White;
            erp.BackColor = PrimaryBlue;

            erp.Padding =
                new Padding(5, 3, 5, 3);

            erp.Location =
                new Point(117, 20);

            panel.Controls.Add(erp);

            // --------------------------------------------------------
            // ARAMA
            // --------------------------------------------------------

            Panel searchPanel = new Panel();

            searchPanel.Location =
                new Point(180, 14);

            searchPanel.Size =
                new Size(520, 37);

            searchPanel.BackColor =
                Color.FromArgb(
                    247,
                    249,
                    252);

            searchPanel.BorderStyle =
                BorderStyle.FixedSingle;

            Label searchIcon = new Label();

            searchIcon.Text = "⌕";

            searchIcon.Font =
                new Font(
                    "Segoe UI",
                    15F);

            searchIcon.ForeColor =
                TextSecondary;

            searchIcon.AutoSize = true;

            searchIcon.Location =
                new Point(10, 4);

            searchPanel.Controls.Add(
                searchIcon);

            TextBox search = new TextBox();

            search.BorderStyle =
                BorderStyle.None;

            search.BackColor =
                searchPanel.BackColor;

            search.ForeColor =
                Color.Gray;

            search.Font =
                new Font(
                    "Segoe UI",
                    9F);

            search.Text =
                "Cari, ürün veya fatura ara (Ctrl + K)...";

            search.Location =
                new Point(40, 10);

            search.Width = 460;

            searchPanel.Controls.Add(search);

            panel.Controls.Add(searchPanel);

            // --------------------------------------------------------
            // KULLANICI
            // --------------------------------------------------------

            Panel userPanel = new Panel();

            userPanel.Size =
                new Size(250, 51);

            userPanel.BackColor =
                Color.White;

            userPanel.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Right;

            Label userName = new Label();

            userName.Text =
                aktifKullaniciAdi;

            userName.AutoSize = false;

            userName.Size =
                new Size(185, 21);

            userName.Location =
                new Point(0, 5);

            userName.TextAlign =
                ContentAlignment.MiddleRight;

            userName.Font =
                new Font(
                    "Segoe UI",
                    8.5F,
                    FontStyle.Bold);

            userName.ForeColor =
                TextPrimary;

            userPanel.Controls.Add(
                userName);

            Label role = new Label();

            role.Text =
                aktifKullaniciRol;

            role.AutoSize = false;

            role.Size =
                new Size(185, 18);

            role.Location =
                new Point(0, 27);

            role.TextAlign =
                ContentAlignment.MiddleRight;

            role.Font =
                new Font(
                    "Segoe UI",
                    7.5F);

            role.ForeColor =
                TextSecondary;

            userPanel.Controls.Add(role);

            Label avatar = new Label();

            avatar.Text =
                KullaniciBasHarfi();

            avatar.Size =
                new Size(40, 40);

            avatar.Location =
                new Point(198, 5);

            avatar.BackColor =
                PrimaryBlue;

            avatar.ForeColor =
                Color.White;

            avatar.TextAlign =
                ContentAlignment.MiddleCenter;

            avatar.Font =
                new Font(
                    "Segoe UI",
                    10F,
                    FontStyle.Bold);

            userPanel.Controls.Add(avatar);

            panel.Controls.Add(userPanel);

            // --------------------------------------------------------
            // RESPONSIVE
            // --------------------------------------------------------

            panel.Resize += delegate
            {
                userPanel.Left =
                    panel.ClientSize.Width -
                    userPanel.Width -
                    20;

                userPanel.Top = 7;

                int available =
                    userPanel.Left -
                    searchPanel.Left -
                    30;

                searchPanel.Width =
                    Math.Max(
                        280,
                        Math.Min(
                            620,
                            available));

                search.Width =
                    Math.Max(
                        190,
                        searchPanel.Width - 55);
            };

            return panel;
        }

        // ============================================================
        // İKİNCİ ÜST BAR
        // ============================================================

        private Panel PageHeaderOlustur()
        {
            Panel panel = new Panel();

            panel.Dock = DockStyle.Top;
            panel.Height = 88;
            panel.BackColor = Color.White;

            // --------------------------------------------------------
            // ALT ÇİZGİ
            // --------------------------------------------------------

            Panel border = new Panel();

            border.Dock =
                DockStyle.Bottom;

            border.Height = 1;

            border.BackColor =
                BorderColor;

            panel.Controls.Add(border);

            // --------------------------------------------------------
            // BREADCRUMB
            // --------------------------------------------------------

            Label breadcrumb =
                new Label();

            breadcrumb.Text =
                "Faturalar   ›   Yeni Fatura Düzenle";

            breadcrumb.AutoSize =
                true;

            breadcrumb.Font =
                new Font(
                    "Segoe UI",
                    8F);

            breadcrumb.ForeColor =
                TextSecondary;

            breadcrumb.Location =
                new Point(22, 10);

            panel.Controls.Add(
                breadcrumb);

            // --------------------------------------------------------
            // BAŞLIK
            // --------------------------------------------------------

            Label title = new Label();

            title.Text =
                "Yeni Fatura Düzenle & GİB Canlı Önizleme";

            title.AutoSize = true;

            title.Font =
                new Font(
                    "Segoe UI",
                    13F,
                    FontStyle.Bold);

            title.ForeColor =
                TextPrimary;

            title.Location =
                new Point(22, 43);

            panel.Controls.Add(title);

            // --------------------------------------------------------
            // GİB BADGE
            // --------------------------------------------------------

            Label sync = new Label();

            sync.Text =
                "●  GİB Portal Canlı Senkron";

            sync.AutoSize = true;

            sync.Font =
                new Font(
                    "Segoe UI",
                    7.5F,
                    FontStyle.Bold);

            sync.ForeColor =
                Success;

            sync.BackColor =
                SuccessBackground;

            sync.Padding =
                new Padding(
                    7,
                    4,
                    7,
                    4);

            sync.Location =
                new Point(390, 42);

            panel.Controls.Add(sync);

            // --------------------------------------------------------
            // BUTONLAR
            // --------------------------------------------------------

            Button taslak =
                WhiteButton(
                    "▣  Taslak Kaydet");

            taslak.Size =
                new Size(115, 36);

            Button yazdir =
                WhiteButton(
                    "▣  Yazdır");

            yazdir.Size =
                new Size(85, 36);

            Button pdf =
                WhiteButton(
                    "▤  PDF İndir");

            pdf.Size =
                new Size(95, 36);

            Button onay =
                BlueButton(
                    "➤  Faturayı Onayla ve GİB'e Gönder");

            onay.Size =
                new Size(235, 36);

            panel.Controls.Add(taslak);
            panel.Controls.Add(yazdir);
            panel.Controls.Add(pdf);
            panel.Controls.Add(onay);

            panel.Resize += delegate
            {
                int right =
                    panel.ClientSize.Width - 20;

                onay.Left =
                    right - onay.Width;

                onay.Top = 37;

                pdf.Left =
                    onay.Left -
                    pdf.Width -
                    8;

                pdf.Top = 37;

                yazdir.Left =
                    pdf.Left -
                    yazdir.Width -
                    8;

                yazdir.Top = 37;

                taslak.Left =
                    yazdir.Left -
                    taslak.Width -
                    8;

                taslak.Top = 37;

                sync.Visible =
                    sync.Right <
                    taslak.Left - 15;
            };

            return panel;
        }

        // ============================================================
        // SOL TARAF
        // ============================================================

        private Panel SolTarafOlustur()
        {
            Panel container =
                new Panel();

            container.Dock =
                DockStyle.Fill;

            container.AutoScroll =
                true;

            container.BackColor =
                LeftBackground;

            // ========================================================
            // FATURA BİLGİLERİ
            // ========================================================

            Panel invoice = Card();

            invoice.Location =
                new Point(12, 12);

            invoice.Size =
                new Size(650, 300);

            invoice.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Left |
                AnchorStyles.Right;

            invoice.Controls.Add(
                SectionTitle(
                    "▣  Fatura & Belge Bilgileri",
                    16,
                    13));

            Label ubl =
                Badge(
                    "UBL-TR 2.1",
                    Color.FromArgb(
                        238,
                        241,
                        245),
                    TextSecondary);

            ubl.Location =
                new Point(555, 10);

            invoice.Controls.Add(ubl);

            invoice.Controls.Add(
                HorizontalLine(
                    16,
                    44,
                    615));

            // --------------------------------------------------------
            // BELGE TÜRÜ
            // --------------------------------------------------------

            invoice.Controls.Add(
                FormLabel(
                    "Belge Türü",
                    16,
                    56));

            Panel belge =
                new Panel();

            belge.Location =
                new Point(16, 77);

            belge.Size =
                new Size(615, 38);

            belge.BorderStyle =
                BorderStyle.FixedSingle;

            belge.BackColor =
                Color.FromArgb(
                    247,
                    250,
                    255);

            Label efatura =
                new Label();

            efatura.Text =
                "●  e-Fatura";

            efatura.AutoSize =
                true;

            efatura.Font =
                new Font(
                    "Segoe UI",
                    8.5F,
                    FontStyle.Bold);

            efatura.ForeColor =
                PrimaryBlue;

            efatura.Location =
                new Point(10, 10);

            belge.Controls.Add(
                efatura);

            Label gib =
                new Label();

            gib.Text =
                "GİB Kayıtlı";

            gib.AutoSize =
                true;

            gib.Font =
                new Font(
                    "Segoe UI",
                    7F);

            gib.ForeColor =
                Success;

            gib.BackColor =
                SuccessBackground;

            gib.Location =
                new Point(120, 10);

            belge.Controls.Add(gib);

            Label earsiv =
                new Label();

            earsiv.Text =
                "○  e-Arşiv Fatura";

            earsiv.AutoSize =
                true;

            earsiv.ForeColor =
                TextSecondary;

            earsiv.Location =
                new Point(320, 10);

            belge.Controls.Add(
                earsiv);

            invoice.Controls.Add(
                belge);

            // --------------------------------------------------------
            // SENARYO
            // --------------------------------------------------------

            invoice.Controls.Add(
                FormLabel(
                    "Senaryo",
                    16,
                    125));

            cmbSenaryo =
                CreateCombo();

            cmbSenaryo.Items.Add(
                "TICARIFATURA (Ticari Fatura)");

            cmbSenaryo.Items.Add(
                "TEMELFATURA (Temel Fatura)");

            cmbSenaryo.SelectedIndex =
                0;

            cmbSenaryo.Location =
                new Point(16, 146);

            cmbSenaryo.Size =
                new Size(295, 29);

            cmbSenaryo.SelectedIndexChanged +=
                VeriDegisti;

            invoice.Controls.Add(
                cmbSenaryo);

            // --------------------------------------------------------
            // FATURA TİPİ
            // --------------------------------------------------------

            invoice.Controls.Add(
                FormLabel(
                    "Fatura Tipi",
                    327,
                    125));

            cmbFaturaTipi =
                CreateCombo();

            cmbFaturaTipi.Items.Add(
                "SATIŞ (Satış)");

            cmbFaturaTipi.Items.Add(
                "İADE (İade)");

            cmbFaturaTipi.SelectedIndex =
                0;

            cmbFaturaTipi.Location =
                new Point(327, 146);

            cmbFaturaTipi.Size =
                new Size(304, 29);

            cmbFaturaTipi.SelectedIndexChanged +=
                VeriDegisti;

            invoice.Controls.Add(
                cmbFaturaTipi);

            // --------------------------------------------------------
            // FATURA NO
            // --------------------------------------------------------

            invoice.Controls.Add(
                FormLabel(
                    "Fatura No",
                    16,
                    185));

            txtFaturaNo =
                CreateTextBox();

            txtFaturaNo.Text =
                "NXR" +
                DateTime.Now.Year +
                "000000143";

            txtFaturaNo.Font =
                new Font(
                    "Segoe UI",
                    8.5F,
                    FontStyle.Bold);

            txtFaturaNo.ForeColor =
                PrimaryBlue;

            txtFaturaNo.Location =
                new Point(16, 206);

            txtFaturaNo.Size =
                new Size(190, 29);

            txtFaturaNo.TextChanged +=
                VeriDegisti;

            invoice.Controls.Add(
                txtFaturaNo);

            // --------------------------------------------------------
            // TARİH
            // --------------------------------------------------------

            invoice.Controls.Add(
                FormLabel(
                    "Fatura Tarihi",
                    220,
                    185));

            dtpTarih =
                new DateTimePicker();

            dtpTarih.Format =
                DateTimePickerFormat.Short;

            dtpTarih.Location =
                new Point(220, 206);

            dtpTarih.Size =
                new Size(190, 29);

            dtpTarih.ValueChanged +=
                VeriDegisti;

            invoice.Controls.Add(
                dtpTarih);

            // --------------------------------------------------------
            // SAAT
            // --------------------------------------------------------

            invoice.Controls.Add(
                FormLabel(
                    "Düzenleme Saati",
                    424,
                    185));

            dtpSaat =
                new DateTimePicker();

            dtpSaat.Format =
                DateTimePickerFormat.Time;

            dtpSaat.ShowUpDown =
                true;

            dtpSaat.Location =
                new Point(424, 206);

            dtpSaat.Size =
                new Size(207, 29);

            dtpSaat.ValueChanged +=
                VeriDegisti;

            invoice.Controls.Add(
                dtpSaat);

            // --------------------------------------------------------
            // PARA BİRİMİ
            // --------------------------------------------------------

            invoice.Controls.Add(
                FormLabel(
                    "Para Birimi & Kur",
                    16,
                    245));

            cmbParaBirimi =
                CreateCombo();

            cmbParaBirimi.Items.Add(
                "TRY - ₺");

            cmbParaBirimi.Items.Add(
                "USD - $");

            cmbParaBirimi.Items.Add(
                "EUR - €");

            cmbParaBirimi.SelectedIndex =
                0;

            cmbParaBirimi.Location =
                new Point(16, 266);

            cmbParaBirimi.Size =
                new Size(140, 29);

            cmbParaBirimi.SelectedIndexChanged +=
                VeriDegisti;

            invoice.Controls.Add(
                cmbParaBirimi);

            TextBox kur =
                CreateTextBox();

            kur.Text = "1.0000";

            kur.TextAlign =
                HorizontalAlignment.Right;

            kur.Location =
                new Point(165, 266);

            kur.Size =
                new Size(140, 29);

            invoice.Controls.Add(kur);

            // --------------------------------------------------------
            // SİPARİŞ
            // --------------------------------------------------------

            invoice.Controls.Add(
                FormLabel(
                    "Sipariş / İrsaliye No",
                    327,
                    245));

            txtSiparisNo =
                CreateTextBox();

            txtSiparisNo.Text =
                "SIP-2025-8842";

            txtSiparisNo.Location =
                new Point(327, 266);

            txtSiparisNo.Size =
                new Size(304, 29);

            invoice.Controls.Add(
                txtSiparisNo);

            container.Controls.Add(
                invoice);

            // ========================================================
            // MÜŞTERİ
            // ========================================================

            Panel customer =
                Card();

            customer.Location =
                new Point(12, 325);

            customer.Size =
                new Size(650, 290);

            customer.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Left |
                AnchorStyles.Right;

            customer.Controls.Add(
                SectionTitle(
                    "▦  Alıcı / Müşteri Bilgileri",
                    16,
                    13));

            customer.Controls.Add(
                HorizontalLine(
                    16,
                    44,
                    615));

            // FİRMA
            customer.Controls.Add(
                FormLabel(
                    "Cari / Firma Unvanı",
                    16,
                    56));

            txtAlici =
                CreateTextBox();

            txtAlici.Location =
                new Point(16, 77);

            txtAlici.Size =
                new Size(615, 29);

            txtAlici.TextChanged +=
                VeriDegisti;

            customer.Controls.Add(
                txtAlici);

            // VKN
            customer.Controls.Add(
                FormLabel(
                    "VKN / TCKN",
                    16,
                    116));

            txtKimlikNo =
                CreateTextBox();

            txtKimlikNo.Location =
                new Point(16, 137);

            txtKimlikNo.Size =
                new Size(295, 29);

            txtKimlikNo.TextChanged +=
                VeriDegisti;

            customer.Controls.Add(
                txtKimlikNo);

            // VERGİ DAİRESİ
            customer.Controls.Add(
                FormLabel(
                    "Vergi Dairesi",
                    327,
                    116));

            txtVergiDairesi =
                CreateTextBox();

            txtVergiDairesi.Location =
                new Point(327, 137);

            txtVergiDairesi.Size =
                new Size(304, 29);

            txtVergiDairesi.TextChanged +=
                VeriDegisti;

            customer.Controls.Add(
                txtVergiDairesi);

            // ADRES
            customer.Controls.Add(
                FormLabel(
                    "Adres",
                    16,
                    176));

            txtAdres =
                CreateTextBox();

            txtAdres.Location =
                new Point(16, 197);

            txtAdres.Size =
                new Size(615, 29);

            txtAdres.TextChanged +=
                VeriDegisti;

            customer.Controls.Add(
                txtAdres);

            // E-POSTA
            customer.Controls.Add(
                FormLabel(
                    "E-Posta (PK Adresi)",
                    16,
                    236));

            txtEmail =
                CreateTextBox();

            txtEmail.Location =
                new Point(16, 257);

            txtEmail.Size =
                new Size(295, 29);

            txtEmail.TextChanged +=
                VeriDegisti;

            customer.Controls.Add(
                txtEmail);

            // TELEFON
            customer.Controls.Add(
                FormLabel(
                    "Telefon",
                    327,
                    236));

            txtTelefon =
                CreateTextBox();

            txtTelefon.Location =
                new Point(327, 257);

            txtTelefon.Size =
                new Size(304, 29);

            txtTelefon.TextChanged +=
                VeriDegisti;

            customer.Controls.Add(
                txtTelefon);

            container.Controls.Add(
                customer);

            // ========================================================
            // FATURA KALEMLERİ
            // ========================================================

            Panel items =
                Card();

            items.Location =
                new Point(12, 628);

            items.Size =
                new Size(650, 355);

            items.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Left |
                AnchorStyles.Right;

            items.Controls.Add(
                SectionTitle(
                    "▤  Fatura Satır Kalemleri",
                    16,
                    13));

            Button sil =
                WhiteButton("Sil");

            sil.Size =
                new Size(60, 30);

            sil.Location =
                new Point(455, 9);

            Button ekle =
                BlueButton(
                    "+  Kalem Ekle");

            ekle.Size =
                new Size(105, 30);

            ekle.Location =
                new Point(526, 9);

            items.Controls.Add(sil);
            items.Controls.Add(ekle);

            dgvKalemler =
                KalemGridOlustur();

            dgvKalemler.Location =
                new Point(16, 54);

            dgvKalemler.Size =
                new Size(615, 282);

            dgvKalemler.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Left |
                AnchorStyles.Right |
                AnchorStyles.Bottom;

            items.Controls.Add(
                dgvKalemler);

            ekle.Click += delegate
            {
                BosKalemEkle();
            };

            sil.Click += delegate
            {
                if (dgvKalemler.CurrentRow != null)
                {
                    dgvKalemler.Rows.Remove(
                        dgvKalemler.CurrentRow);

                    OnizlemeyiGuncelle();
                }
            };

            container.Controls.Add(
                items);

            // ========================================================
            // RESPONSIVE
            // ========================================================

            container.Resize += delegate
            {
                int width =
                    Math.Max(
                        650,
                        container.ClientSize.Width -
                        24);

                invoice.Width = width;
                customer.Width = width;
                items.Width = width;

                belge.Width =
                    width - 32;

                txtAlici.Width =
                    width - 32;

                txtAdres.Width =
                    width - 32;

                dgvKalemler.Width =
                    width - 32;

                ubl.Left =
                    width -
                    ubl.Width -
                    16;

                ekle.Left =
                    width -
                    ekle.Width -
                    16;

                sil.Left =
                    ekle.Left -
                    sil.Width -
                    8;
            };

            return container;
        }

        // ============================================================
        // SOL GRID
        // ============================================================

        private DataGridView KalemGridOlustur()
        {
            DataGridView grid =
                new DataGridView();

            grid.BackgroundColor =
                Color.White;

            grid.BorderStyle =
                BorderStyle.FixedSingle;

            grid.RowHeadersVisible =
                false;

            grid.AllowUserToAddRows =
                false;

            grid.AllowUserToDeleteRows =
                false;

            grid.MultiSelect =
                false;

            grid.SelectionMode =
                DataGridViewSelectionMode.FullRowSelect;

            grid.EditMode =
                DataGridViewEditMode.EditOnEnter;

            grid.AutoSizeColumnsMode =
                DataGridViewAutoSizeColumnsMode.Fill;

            grid.EnableHeadersVisualStyles =
                false;

            grid.ColumnHeadersHeight =
                38;

            grid.RowTemplate.Height =
                42;

            grid.GridColor =
                BorderColor;

            grid.ColumnHeadersDefaultCellStyle.BackColor =
                Color.FromArgb(
                    240,
                    245,
                    250);

            grid.ColumnHeadersDefaultCellStyle.Font =
                new Font(
                    "Segoe UI",
                    7.5F,
                    FontStyle.Bold);

            grid.DefaultCellStyle.Font =
                new Font(
                    "Segoe UI",
                    8F);

            grid.Columns.Add(
                "StokKodu",
                "Kod");

            grid.Columns.Add(
                "Urun",
                "Mal / Hizmet Açıklaması");

            grid.Columns.Add(
                "Miktar",
                "Miktar");

            grid.Columns.Add(
                "Birim",
                "Birim");

            grid.Columns.Add(
                "BirimFiyat",
                "Birim Fiyat");

            grid.Columns.Add(
                "Iskonto",
                "İskonto %");

            DataGridViewComboBoxColumn kdv =
                new DataGridViewComboBoxColumn();

            kdv.Name = "Kdv";
            kdv.HeaderText = "KDV %";

            kdv.Items.Add("0");
            kdv.Items.Add("1");
            kdv.Items.Add("10");
            kdv.Items.Add("20");

            grid.Columns.Add(kdv);

            grid.Columns.Add(
                "Toplam",
                "Satır Toplamı");

            grid.Columns["Toplam"].ReadOnly =
                true;

            grid.Columns["StokKodu"].FillWeight =
                55;

            grid.Columns["Urun"].FillWeight =
                190;

            grid.Columns["Miktar"].FillWeight =
                55;

            grid.Columns["Birim"].FillWeight =
                55;

            grid.Columns["BirimFiyat"].FillWeight =
                75;

            grid.Columns["Iskonto"].FillWeight =
                60;

            grid.Columns["Kdv"].FillWeight =
                55;

            grid.Columns["Toplam"].FillWeight =
                90;

            grid.CellValueChanged +=
                delegate (
                    object sender,
                    DataGridViewCellEventArgs e)
                {
                    if (hesaplamaYapiliyor)
                        return;

                    if (e.RowIndex < 0)
                        return;

                    SatirHesapla(
                        e.RowIndex);

                    OnizlemeyiGuncelle();
                };

            grid.CellEndEdit += delegate
            {
                OnizlemeyiGuncelle();
            };

            grid.CurrentCellDirtyStateChanged +=
                delegate
                {
                    if (grid.IsCurrentCellDirty)
                    {
                        grid.CommitEdit(
                            DataGridViewDataErrorContexts.Commit);
                    }
                };

            grid.DataError += delegate
            {
                // ComboBox DataError uygulamayı durdurmasın.
            };

            return grid;
        }

        // ============================================================
        // SAĞ TARAF
        // ============================================================

        private Panel SagTarafOlustur()
        {
            Panel background =
                new Panel();

            background.Dock =
                DockStyle.Fill;

            background.AutoScroll =
                true;

            background.BackColor =
                RightBackground;

            // ========================================================
            // PREVIEW TOOLBAR
            // ========================================================

            Panel toolbar =
                new Panel();

            toolbar.Location =
                new Point(12, 12);

            toolbar.Height = 50;

            toolbar.BackColor =
                Color.White;

            toolbar.BorderStyle =
                BorderStyle.FixedSingle;

            toolbar.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Left |
                AnchorStyles.Right;

            Label live =
                new Label();

            live.Text =
                "●  GİB Standart E-Fatura Çıktısı";

            live.AutoSize =
                true;

            live.Font =
                new Font(
                    "Segoe UI",
                    9F,
                    FontStyle.Bold);

            live.ForeColor =
                TextPrimary;

            live.Location =
                new Point(14, 15);

            toolbar.Controls.Add(live);

            Label zoom =
                new Label();

            zoom.Text =
                "⌕     100%     ⊕     ⛶";

            zoom.AutoSize =
                true;

            zoom.ForeColor =
                TextSecondary;

            zoom.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Right;

            toolbar.Controls.Add(zoom);

            toolbar.Resize += delegate
            {
                zoom.Left =
                    toolbar.ClientSize.Width -
                    zoom.Width -
                    15;

                zoom.Top = 16;
            };

            background.Controls.Add(
                toolbar);

            // ========================================================
            // A4 KAĞIT
            // ========================================================

            Panel paper =
                new Panel();

            paper.Location =
                new Point(12, 75);

            paper.Size =
                new Size(800, 1060);

            paper.BackColor =
                Color.White;

            paper.BorderStyle =
                BorderStyle.FixedSingle;

            background.Controls.Add(
                paper);

            // --------------------------------------------------------
            // GİB LOGO
            // --------------------------------------------------------

            Panel gibLogo =
                new Panel();

            gibLogo.Location =
                new Point(35, 35);

            gibLogo.Size =
                new Size(54, 54);

            gibLogo.BackColor =
                Color.FromArgb(
                    190,
                    20,
                    25);

            Label gibText =
                new Label();

            gibText.Text =
                "GİB\nE-BELGE";

            gibText.Dock =
                DockStyle.Fill;

            gibText.TextAlign =
                ContentAlignment.MiddleCenter;

            gibText.ForeColor =
                Color.White;

            gibText.Font =
                new Font(
                    "Segoe UI",
                    8F,
                    FontStyle.Bold);

            gibLogo.Controls.Add(
                gibText);

            paper.Controls.Add(
                gibLogo);

            // --------------------------------------------------------
            // KURUM
            // --------------------------------------------------------

            Label kurum =
                new Label();

            kurum.Text =
                "GELİR İDARESİ\nBAŞKANLIĞI";

            kurum.AutoSize =
                true;

            kurum.Font =
                new Font(
                    "Segoe UI",
                    11F,
                    FontStyle.Bold);

            kurum.Location =
                new Point(103, 35);

            paper.Controls.Add(
                kurum);

            Label portal =
                new Label();

            portal.Text =
                "e-Fatura / e-Arşiv Portal\n" +
                "UBL-TR 2.1 • Schematron\n" +
                "Doğrulandı";

            portal.AutoSize =
                true;

            portal.Font =
                new Font(
                    "Consolas",
                    7F);

            portal.ForeColor =
                Color.FromArgb(
                    115,
                    128,
                    145);

            portal.Location =
                new Point(103, 72);

            paper.Controls.Add(
                portal);

            // --------------------------------------------------------
            // E-FATURA
            // --------------------------------------------------------

            Label efaturaTitle =
                new Label();

            efaturaTitle.Text =
                "E-FATURA";

            efaturaTitle.AutoSize =
                true;

            efaturaTitle.Font =
                new Font(
                    "Segoe UI",
                    16F,
                    FontStyle.Bold);

            efaturaTitle.ForeColor =
                Color.FromArgb(
                    194,
                    20,
                    20);

            paper.Controls.Add(
                efaturaTitle);

            // ========================================================
            // META
            // ========================================================

            Panel meta =
                new Panel();

            meta.Size =
                new Size(310, 115);

            meta.BackColor =
                Color.White;

            prvFaturaNo =
                MetaLabel(0);

            prvTarih =
                MetaLabel(22);

            prvSaat =
                MetaLabel(44);

            prvSenaryo =
                MetaLabel(66);

            prvTip =
                MetaLabel(88);

            meta.Controls.Add(
                prvFaturaNo);

            meta.Controls.Add(
                prvTarih);

            meta.Controls.Add(
                prvSaat);

            meta.Controls.Add(
                prvSenaryo);

            meta.Controls.Add(
                prvTip);

            paper.Controls.Add(meta);

            // --------------------------------------------------------
            // AYIRICI
            // --------------------------------------------------------

            Panel line =
                new Panel();

            line.Location =
                new Point(35, 185);

            line.Height = 2;

            line.BackColor =
                Color.FromArgb(
                    25,
                    25,
                    25);

            paper.Controls.Add(line);

            // --------------------------------------------------------
            // ETTN
            // --------------------------------------------------------

            Panel ettn =
                new Panel();

            ettn.Location =
                new Point(35, 200);

            ettn.Height = 34;

            ettn.BackColor =
                Color.FromArgb(
                    247,
                    249,
                    252);

            ettn.BorderStyle =
                BorderStyle.FixedSingle;

            Label ettnText =
                new Label();

            ettnText.Text =
                "ETTN (UUID): a4f88c20-891d-48d6-947b-1...    " +
                "Karekod: ▦    Doğrulanabilir GİB İmzalı";

            ettnText.AutoSize =
                true;

            ettnText.Font =
                new Font(
                    "Consolas",
                    7F);

            ettnText.ForeColor =
                TextSecondary;

            ettnText.Location =
                new Point(10, 9);

            ettn.Controls.Add(
                ettnText);

            paper.Controls.Add(ettn);

            // ========================================================
            // SATICI
            // ========================================================

            Panel seller =
                InfoBox();

            seller.Location =
                new Point(35, 250);

            Label sellerTitle =
                new Label();

            sellerTitle.Text =
                "SAYIN SATICI (GÖNDERİCİ)";

            sellerTitle.AutoSize =
                true;

            sellerTitle.Font =
                new Font(
                    "Segoe UI",
                    7.5F,
                    FontStyle.Bold);

            sellerTitle.ForeColor =
                Color.FromArgb(
                    190,
                    25,
                    25);

            sellerTitle.Location =
                new Point(11, 10);

            seller.Controls.Add(
                sellerTitle);

            Label sellerText =
                new Label();

            sellerText.Text =
                "NEXORA TEKNOLOJİ VE YAZILIM A.Ş.\n\n" +
                "Maslak Mah. Büyükdere Cad. No:194\n" +
                "K:8 Şişli / İstanbul\n" +
                "Vergi Dairesi: Maslak V.D.\n" +
                "VKN: 6310849201\n" +
                "E-Posta: muhasebe@nexora.com.tr";

            sellerText.Location =
                new Point(11, 39);

            sellerText.Size =
                new Size(310, 155);

            sellerText.Font =
                new Font(
                    "Segoe UI",
                    7.5F);

            seller.Controls.Add(
                sellerText);

            paper.Controls.Add(
                seller);

            // ========================================================
            // ALICI
            // ========================================================

            Panel buyer =
                InfoBox();

            buyer.Location =
                new Point(390, 250);

            Label buyerTitle =
                new Label();

            buyerTitle.Text =
                "SAYIN ALICI (MÜŞTERİ)";

            buyerTitle.AutoSize =
                true;

            buyerTitle.Font =
                new Font(
                    "Segoe UI",
                    7.5F,
                    FontStyle.Bold);

            buyerTitle.ForeColor =
                Color.FromArgb(
                    20,
                    80,
                    165);

            buyerTitle.Location =
                new Point(11, 10);

            buyer.Controls.Add(
                buyerTitle);

            Label registered =
                new Label();

            registered.Text =
                "● GİB KAYITLI";

            registered.AutoSize =
                true;

            registered.ForeColor =
                Success;

            registered.Font =
                new Font(
                    "Segoe UI",
                    7F,
                    FontStyle.Bold);

            buyer.Controls.Add(
                registered);

            buyer.Resize += delegate
            {
                registered.Left =
                    buyer.ClientSize.Width -
                    registered.Width -
                    10;

                registered.Top = 10;
            };

            prvAlici =
                new Label();

            prvAlici.Location =
                new Point(11, 39);

            prvAlici.Size =
                new Size(315, 38);

            prvAlici.Font =
                new Font(
                    "Segoe UI",
                    8.5F,
                    FontStyle.Bold);

            buyer.Controls.Add(
                prvAlici);

            prvAdres =
                InvoiceInfoLabel(
                    11,
                    80);

            prvVergi =
                InvoiceInfoLabel(
                    11,
                    111);

            prvKimlik =
                InvoiceInfoLabel(
                    11,
                    132);

            prvEmail =
                InvoiceInfoLabel(
                    11,
                    153);

            prvTelefon =
                InvoiceInfoLabel(
                    11,
                    174);

            buyer.Controls.Add(
                prvAdres);

            buyer.Controls.Add(
                prvVergi);

            buyer.Controls.Add(
                prvKimlik);

            buyer.Controls.Add(
                prvEmail);

            buyer.Controls.Add(
                prvTelefon);

            paper.Controls.Add(
                buyer);

            // ========================================================
            // FATURA TABLOSU
            // ========================================================

            dgvOnizleme =
                PreviewGridOlustur();

            dgvOnizleme.Location =
                new Point(35, 480);

            dgvOnizleme.Size =
                new Size(730, 315);

            paper.Controls.Add(
                dgvOnizleme);

            // ========================================================
            // NOTLAR
            // ========================================================

            Panel notes =
                new Panel();

            notes.Location =
                new Point(35, 815);

            notes.Size =
                new Size(390, 145);

            notes.BackColor =
                Color.White;

            notes.BorderStyle =
                BorderStyle.FixedSingle;

            Label noteTitle =
                new Label();

            noteTitle.Text =
                "NOTLAR VE AÇIKLAMALAR";

            noteTitle.AutoSize =
                true;

            noteTitle.Font =
                new Font(
                    "Segoe UI",
                    7.5F,
                    FontStyle.Bold);

            noteTitle.Location =
                new Point(10, 10);

            notes.Controls.Add(
                noteTitle);

            Label note =
                new Label();

            note.Text =
                "Fatura ile ilgili açıklamalar bu alanda gösterilir.\n\n" +
                "Ödeme Vadesi: 30 Gün";

            note.Location =
                new Point(10, 35);

            note.Size =
                new Size(360, 90);

            note.Font =
                new Font(
                    "Segoe UI",
                    7F);

            notes.Controls.Add(
                note);

            paper.Controls.Add(
                notes);

            // ========================================================
            // TOPLAMLAR
            // ========================================================

            Panel total =
                new Panel();

            total.Size =
                new Size(320, 145);

            total.BackColor =
                Color.White;

            total.BorderStyle =
                BorderStyle.FixedSingle;

            prvAraToplam =
                TotalLabel(
                    10,
                    10);

            prvIskonto =
                TotalLabel(
                    10,
                    40);

            prvKdv =
                TotalLabel(
                    10,
                    70);

            prvGenelToplam =
                TotalLabel(
                    10,
                    105);

            prvGenelToplam.Font =
                new Font(
                    "Segoe UI",
                    9F,
                    FontStyle.Bold);

            prvGenelToplam.ForeColor =
                PrimaryBlue;

            total.Controls.Add(
                prvAraToplam);

            total.Controls.Add(
                prvIskonto);

            total.Controls.Add(
                prvKdv);

            total.Controls.Add(
                prvGenelToplam);

            paper.Controls.Add(
                total);

            // ========================================================
            // RESPONSIVE
            // ========================================================

            background.Resize += delegate
            {
                toolbar.Width =
                    Math.Max(
                        650,
                        background.ClientSize.Width -
                        24);

                int available =
                    Math.Max(
                        760,
                        background.ClientSize.Width -
                        24);

                paper.Width =
                    Math.Min(
                        940,
                        available);

                paper.Left =
                    Math.Max(
                        12,
                        (
                            background.ClientSize.Width -
                            paper.Width
                        ) / 2);

                int pw =
                    paper.ClientSize.Width;

                int contentWidth =
                    pw - 70;

                efaturaTitle.Left =
                    pw -
                    efaturaTitle.Width -
                    35;

                efaturaTitle.Top =
                    35;

                meta.Left =
                    pw -
                    meta.Width -
                    35;

                meta.Top =
                    70;

                line.Width =
                    contentWidth;

                ettn.Width =
                    contentWidth;

                int gap = 16;

                int boxWidth =
                    (contentWidth - gap) / 2;

                seller.Width =
                    boxWidth;

                buyer.Left =
                    35 +
                    boxWidth +
                    gap;

                buyer.Width =
                    boxWidth;

                dgvOnizleme.Width =
                    contentWidth;

                total.Left =
                    pw -
                    total.Width -
                    35;

                total.Top =
                    815;

                notes.Width =
                    Math.Max(
                        300,
                        contentWidth -
                        total.Width -
                        16);
            };

            return background;
        }

        // ============================================================
        // PREVIEW GRID
        // ============================================================

        private DataGridView PreviewGridOlustur()
        {
            DataGridView grid =
                new DataGridView();

            grid.BackgroundColor =
                Color.White;

            grid.BorderStyle =
                BorderStyle.FixedSingle;

            grid.RowHeadersVisible =
                false;

            grid.AllowUserToAddRows =
                false;

            grid.AllowUserToDeleteRows =
                false;

            grid.AllowUserToResizeRows =
                false;

            grid.ReadOnly = true;

            grid.AutoSizeColumnsMode =
                DataGridViewAutoSizeColumnsMode.Fill;

            grid.EnableHeadersVisualStyles =
                false;

            grid.ColumnHeadersHeight =
                48;

            grid.RowTemplate.Height =
                60;

            grid.GridColor =
                Color.FromArgb(
                    199,
                    213,
                    228);

            grid.ColumnHeadersDefaultCellStyle.BackColor =
                Color.FromArgb(
                    239,
                    245,
                    251);

            grid.ColumnHeadersDefaultCellStyle.Font =
                new Font(
                    "Segoe UI",
                    7F,
                    FontStyle.Bold);

            grid.DefaultCellStyle.Font =
                new Font(
                    "Segoe UI",
                    7F);

            grid.DefaultCellStyle.WrapMode =
                DataGridViewTriState.True;

            grid.Columns.Add(
                "No",
                "#");

            grid.Columns.Add(
                "Urun",
                "Mal / Hizmet Açıklaması");

            grid.Columns.Add(
                "Miktar",
                "Miktar");

            grid.Columns.Add(
                "Birim",
                "Birim");

            grid.Columns.Add(
                "Fiyat",
                "Birim Fiyat");

            grid.Columns.Add(
                "Iskonto",
                "İskonto");

            grid.Columns.Add(
                "Kdv",
                "KDV");

            grid.Columns.Add(
                "KdvTutari",
                "KDV Tutarı");

            grid.Columns.Add(
                "Toplam",
                "Mal Hizmet Tutarı");

            grid.Columns["No"].FillWeight =
                25;

            grid.Columns["Urun"].FillWeight =
                165;

            grid.Columns["Miktar"].FillWeight =
                55;

            grid.Columns["Birim"].FillWeight =
                55;

            grid.Columns["Fiyat"].FillWeight =
                75;

            grid.Columns["Iskonto"].FillWeight =
                55;

            grid.Columns["Kdv"].FillWeight =
                50;

            grid.Columns["KdvTutari"].FillWeight =
                70;

            grid.Columns["Toplam"].FillWeight =
                85;

            return grid;
        }

        // ============================================================
        // ÖRNEK KALEMLER
        // ============================================================

        private void OrnekKalemleriYukle()
        {
            if (dgvKalemler.Rows.Count > 0)
                return;

            KalemEkle(
                "STK-09",
                "ERP Lisansı V3 (10 Kullanıcılı)",
                1,
                "Adet",
                50000,
                10,
                20);

            KalemEkle(
                "SRV-02",
                "Bulut Sunucu & Yedekleme Altyapısı",
                12,
                "Ay",
                2500,
                0,
                20);

            KalemEkle(
                "SRV-05",
                "E-Fatura Entegrasyon Danışmanlık Paketi",
                2,
                "Gün",
                7500,
                0,
                20);
        }

        private void KalemEkle(
            string kod,
            string urun,
            decimal miktar,
            string birim,
            decimal fiyat,
            decimal iskonto,
            decimal kdv)
        {
            int index =
                dgvKalemler.Rows.Add();

            DataGridViewRow row =
                dgvKalemler.Rows[index];

            row.Cells["StokKodu"].Value =
                kod;

            row.Cells["Urun"].Value =
                urun;

            row.Cells["Miktar"].Value =
                miktar.ToString();

            row.Cells["Birim"].Value =
                birim;

            row.Cells["BirimFiyat"].Value =
                fiyat.ToString();

            row.Cells["Iskonto"].Value =
                iskonto.ToString();

            row.Cells["Kdv"].Value =
                kdv.ToString();

            SatirHesapla(index);
        }

        private void BosKalemEkle()
        {
            int index =
                dgvKalemler.Rows.Add();

            DataGridViewRow row =
                dgvKalemler.Rows[index];

            row.Cells["Miktar"].Value =
                "1";

            row.Cells["Birim"].Value =
                "Adet";

            row.Cells["BirimFiyat"].Value =
                "0";

            row.Cells["Iskonto"].Value =
                "0";

            row.Cells["Kdv"].Value =
                "20";

            row.Cells["Toplam"].Value =
                "0,00";

            dgvKalemler.CurrentCell =
                row.Cells["Urun"];

            dgvKalemler.BeginEdit(true);

            OnizlemeyiGuncelle();
        }

        // ============================================================
        // SATIR HESAPLAMA
        // ============================================================

        private void SatirHesapla(
            int index)
        {
            if (index < 0)
                return;

            if (index >=
                dgvKalemler.Rows.Count)
                return;

            hesaplamaYapiliyor =
                true;

            try
            {
                DataGridViewRow row =
                    dgvKalemler.Rows[index];

                decimal miktar =
                    DecimalDeger(
                        row.Cells["Miktar"].Value);

                decimal fiyat =
                    DecimalDeger(
                        row.Cells["BirimFiyat"].Value);

                decimal iskonto =
                    DecimalDeger(
                        row.Cells["Iskonto"].Value);

                decimal kdv =
                    DecimalDeger(
                        row.Cells["Kdv"].Value);

                decimal brut =
                    miktar * fiyat;

                decimal indirim =
                    brut *
                    iskonto /
                    100m;

                decimal matrah =
                    brut -
                    indirim;

                decimal kdvTutari =
                    matrah *
                    kdv /
                    100m;

                decimal toplam =
                    matrah +
                    kdvTutari;

                row.Cells["Toplam"].Value =
                    toplam.ToString("N2");
            }
            finally
            {
                hesaplamaYapiliyor =
                    false;
            }
        }

        // ============================================================
        // CANLI ÖNİZLEME
        // ============================================================

        private void VeriDegisti(
            object sender,
            EventArgs e)
        {
            OnizlemeyiGuncelle();
        }

        private void OnizlemeyiGuncelle()
        {
            if (prvAlici == null)
                return;

            if (dgvOnizleme == null)
                return;

            if (dgvKalemler == null)
                return;

            // --------------------------------------------------------
            // FATURA
            // --------------------------------------------------------

            prvFaturaNo.Text =
                "Fatura No:  " +
                BosIseTire(
                    txtFaturaNo.Text);

            prvTarih.Text =
                "Düzenleme Tarihi:  " +
                dtpTarih.Value.ToString(
                    "dd.MM.yyyy");

            prvSaat.Text =
                "Düzenleme Zamanı:  " +
                dtpSaat.Value.ToString(
                    "HH:mm:ss");

            if (cmbSenaryo.SelectedIndex == 0)
            {
                prvSenaryo.Text =
                    "Senaryo:  TICARIFATURA";
            }
            else
            {
                prvSenaryo.Text =
                    "Senaryo:  TEMELFATURA";
            }

            if (cmbFaturaTipi.SelectedIndex == 0)
            {
                prvTip.Text =
                    "Fatura Tipi:  SATIŞ";
            }
            else
            {
                prvTip.Text =
                    "Fatura Tipi:  İADE";
            }

            // --------------------------------------------------------
            // MÜŞTERİ
            // --------------------------------------------------------

            prvAlici.Text =
                BosIseTire(
                    txtAlici.Text);

            prvAdres.Text =
                BosIseTire(
                    txtAdres.Text);

            prvVergi.Text =
                "Vergi Dairesi: " +
                BosIseTire(
                    txtVergiDairesi.Text);

            prvKimlik.Text =
                "VKN/TCKN: " +
                BosIseTire(
                    txtKimlikNo.Text);

            prvEmail.Text =
                "E-Posta: " +
                BosIseTire(
                    txtEmail.Text);

            prvTelefon.Text =
                "Telefon: " +
                BosIseTire(
                    txtTelefon.Text);

            // --------------------------------------------------------
            // TABLO
            // --------------------------------------------------------

            dgvOnizleme.Rows.Clear();

            decimal brutToplam =
                0m;

            decimal iskontoToplam =
                0m;

            decimal kdvToplam =
                0m;

            decimal genelToplam =
                0m;

            int sira = 1;

            foreach (
                DataGridViewRow row
                in dgvKalemler.Rows)
            {
                string urun =
                    Deger(
                        row,
                        "Urun");

                string birim =
                    Deger(
                        row,
                        "Birim");

                decimal miktar =
                    DecimalDeger(
                        row.Cells["Miktar"].Value);

                decimal fiyat =
                    DecimalDeger(
                        row.Cells["BirimFiyat"].Value);

                decimal iskonto =
                    DecimalDeger(
                        row.Cells["Iskonto"].Value);

                decimal kdv =
                    DecimalDeger(
                        row.Cells["Kdv"].Value);

                decimal brut =
                    miktar *
                    fiyat;

                decimal iskontoTutari =
                    brut *
                    iskonto /
                    100m;

                decimal matrah =
                    brut -
                    iskontoTutari;

                decimal kdvTutari =
                    matrah *
                    kdv /
                    100m;

                decimal toplam =
                    matrah +
                    kdvTutari;

                if (
                    !string.IsNullOrWhiteSpace(
                        urun) ||
                    fiyat > 0)
                {
                    dgvOnizleme.Rows.Add(
                        sira++,
                        string.IsNullOrWhiteSpace(
                            urun)
                            ? "-"
                            : urun,

                        miktar.ToString(
                            "N0"),

                        string.IsNullOrWhiteSpace(
                            birim)
                            ? "-"
                            : birim,

                        fiyat.ToString(
                            "N2") +
                        " " +
                        ParaBirimi(),

                        iskonto > 0
                            ? "%" +
                              iskonto.ToString(
                                  "N0")
                            : "-",

                        "%" +
                        kdv.ToString(
                            "N0"),

                        kdvTutari.ToString(
                            "N2") +
                        " " +
                        ParaBirimi(),

                        matrah.ToString(
                            "N2") +
                        " " +
                        ParaBirimi());
                }

                brutToplam +=
                    brut;

                iskontoToplam +=
                    iskontoTutari;

                kdvToplam +=
                    kdvTutari;

                genelToplam +=
                    toplam;
            }

            // --------------------------------------------------------
            // TOPLAMLAR
            // --------------------------------------------------------

            prvAraToplam.Text =
                "Mal / Hizmet Toplamı:   " +
                brutToplam.ToString(
                    "N2") +
                " " +
                ParaBirimi();

            prvIskonto.Text =
                "Toplam İskonto:   " +
                iskontoToplam.ToString(
                    "N2") +
                " " +
                ParaBirimi();

            prvKdv.Text =
                "Hesaplanan KDV:   " +
                kdvToplam.ToString(
                    "N2") +
                " " +
                ParaBirimi();

            prvGenelToplam.Text =
                "ÖDENECEK TUTAR:   " +
                genelToplam.ToString(
                    "N2") +
                " " +
                ParaBirimi();
        }

        // ============================================================
        // DEĞER HELPERS
        // ============================================================

        private string BosIseTire(
            string text)
        {
            if (string.IsNullOrWhiteSpace(
                text))
            {
                return "-";
            }

            return text.Trim();
        }

        private string ParaBirimi()
        {
            if (cmbParaBirimi == null)
                return "₺";

            if (cmbParaBirimi.SelectedIndex == 1)
                return "$";

            if (cmbParaBirimi.SelectedIndex == 2)
                return "€";

            return "₺";
        }

        private decimal DecimalDeger(
            object value)
        {
            if (value == null)
                return 0m;

            string text =
                value.ToString();

            decimal result;

            if (
                decimal.TryParse(
                    text,
                    NumberStyles.Any,
                    CultureInfo.CurrentCulture,
                    out result))
            {
                return result;
            }

            text =
                text.Replace(
                    ",",
                    ".");

            if (
                decimal.TryParse(
                    text,
                    NumberStyles.Any,
                    CultureInfo.InvariantCulture,
                    out result))
            {
                return result;
            }

            return 0m;
        }

        private string Deger(
            DataGridViewRow row,
            string column)
        {
            object value =
                row.Cells[column].Value;

            if (value == null)
                return "";

            return value.ToString();
        }

        // ============================================================
        // UI HELPERS
        // ============================================================

        private Panel Card()
        {
            Panel panel =
                new Panel();

            panel.BackColor =
                Color.White;

            panel.BorderStyle =
                BorderStyle.FixedSingle;

            return panel;
        }

        private Label SectionTitle(
            string text,
            int x,
            int y)
        {
            Label label =
                new Label();

            label.Text =
                text;

            label.AutoSize =
                true;

            label.Font =
                new Font(
                    "Segoe UI",
                    9F,
                    FontStyle.Bold);

            label.ForeColor =
                TextPrimary;

            label.Location =
                new Point(
                    x,
                    y);

            return label;
        }

        private Label FormLabel(
            string text,
            int x,
            int y)
        {
            Label label =
                new Label();

            label.Text =
                text;

            label.AutoSize =
                true;

            label.Font =
                new Font(
                    "Segoe UI",
                    7.5F,
                    FontStyle.Bold);

            label.ForeColor =
                Color.FromArgb(
                    65,
                    75,
                    88);

            label.Location =
                new Point(
                    x,
                    y);

            return label;
        }

        private Label Badge(
            string text,
            Color back,
            Color fore)
        {
            Label label =
                new Label();

            label.Text =
                text;

            label.AutoSize =
                true;

            label.BackColor =
                back;

            label.ForeColor =
                fore;

            label.Font =
                new Font(
                    "Segoe UI",
                    7F);

            label.Padding =
                new Padding(
                    5,
                    3,
                    5,
                    3);

            return label;
        }

        private TextBox CreateTextBox()
        {
            TextBox box =
                new TextBox();

            box.BorderStyle =
                BorderStyle.FixedSingle;

            box.BackColor =
                Color.White;

            box.ForeColor =
                TextPrimary;

            box.Font =
                new Font(
                    "Segoe UI",
                    8.5F);

            return box;
        }

        private ComboBox CreateCombo()
        {
            ComboBox combo =
                new ComboBox();

            combo.DropDownStyle =
                ComboBoxStyle.DropDownList;

            combo.BackColor =
                Color.White;

            combo.ForeColor =
                TextPrimary;

            combo.Font =
                new Font(
                    "Segoe UI",
                    8F);

            return combo;
        }

        private Button BlueButton(
            string text)
        {
            Button button =
                new Button();

            button.Text =
                text;

            button.FlatStyle =
                FlatStyle.Flat;

            button.BackColor =
                PrimaryBlue;

            button.ForeColor =
                Color.White;

            button.Font =
                new Font(
                    "Segoe UI",
                    8F,
                    FontStyle.Bold);

            button.Cursor =
                Cursors.Hand;

            button.FlatAppearance.BorderSize =
                0;

            button.MouseEnter += delegate
            {
                button.BackColor =
                    PrimaryBlueDark;
            };

            button.MouseLeave += delegate
            {
                button.BackColor =
                    PrimaryBlue;
            };

            return button;
        }

        private Button WhiteButton(
            string text)
        {
            Button button =
                new Button();

            button.Text =
                text;

            button.FlatStyle =
                FlatStyle.Flat;

            button.BackColor =
                Color.White;

            button.ForeColor =
                TextPrimary;

            button.Font =
                new Font(
                    "Segoe UI",
                    8F);

            button.Cursor =
                Cursors.Hand;

            button.FlatAppearance.BorderSize =
                1;

            button.FlatAppearance.BorderColor =
                BorderColor;

            return button;
        }

        private Panel HorizontalLine(
            int x,
            int y,
            int width)
        {
            Panel line =
                new Panel();

            line.Location =
                new Point(
                    x,
                    y);

            line.Size =
                new Size(
                    width,
                    1);

            line.BackColor =
                BorderColor;

            line.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Left |
                AnchorStyles.Right;

            return line;
        }

        private Panel InfoBox()
        {
            Panel panel =
                new Panel();

            panel.Size =
                new Size(
                    340,
                    215);

            panel.BackColor =
                Color.White;

            panel.BorderStyle =
                BorderStyle.FixedSingle;

            return panel;
        }

        private Label InvoiceInfoLabel(
            int x,
            int y)
        {
            Label label =
                new Label();

            label.Location =
                new Point(
                    x,
                    y);

            label.Size =
                new Size(
                    315,
                    22);

            label.Font =
                new Font(
                    "Segoe UI",
                    7F);

            label.ForeColor =
                TextPrimary;

            return label;
        }

        private Label MetaLabel(
            int y)
        {
            Label label =
                new Label();

            label.Location =
                new Point(
                    0,
                    y);

            label.Size =
                new Size(
                    305,
                    20);

            label.TextAlign =
                ContentAlignment.MiddleRight;

            label.Font =
                new Font(
                    "Consolas",
                    7F);

            label.ForeColor =
                Color.FromArgb(
                    55,
                    65,
                    78);

            return label;
        }

        private Label TotalLabel(
            int x,
            int y)
        {
            Label label =
                new Label();

            label.Location =
                new Point(
                    x,
                    y);

            label.Size =
                new Size(
                    295,
                    27);

            label.TextAlign =
                ContentAlignment.MiddleRight;

            label.Font =
                new Font(
                    "Segoe UI",
                    7.5F);

            label.ForeColor =
                TextPrimary;

            return label;
        }
    }
}